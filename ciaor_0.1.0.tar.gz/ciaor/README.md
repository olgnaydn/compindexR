# ciao_r
R version of ciao which is a MATLAB package